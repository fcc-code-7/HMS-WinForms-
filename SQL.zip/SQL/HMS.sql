--dbms project
CREATE TABLE Hostel (
    Hostel_ID INT PRIMARY KEY,
    Hostel_Name VARCHAR(255) NOT NULL,
    Hostel_Location VARCHAR(255) NOT NULL
);

CREATE TABLE Room (
    Room_Number INT PRIMARY KEY,
    Type VARCHAR(255) NOT NULL,
    Capacity INT NOT NULL,
    Availability char(30) NOT NULL
);

CREATE TABLE Student (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Email VARCHAR(255) UNIQUE NOT NULL,
    Phone VARCHAR(255) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    Room_Number INT,
    FOREIGN KEY (Room_Number) REFERENCES Room(Room_Number),
	Hostel_ID INT,
    FOREIGN KEY (Hostel_ID) REFERENCES Hostel(Hostel_ID),
    Date_of_Admission DATE NOT NULL
);

CREATE TABLE Staff (
    Staff_ID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Email VARCHAR(255) UNIQUE NOT NULL,
    Phone VARCHAR(255) NOT NULL,
    Address VARCHAR(255) NOT NULL,
	Hostel_ID int,
	FOREIGN KEY (Hostel_ID) REFERENCES Hostel(Hostel_ID),
    Designation VARCHAR(255) NOT NULL,
    Date_of_Joining DATE NOT NULL
);

CREATE TABLE Allotment (
    Allotment_ID INT PRIMARY KEY,
    Student_ID INT,
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    Room_Number INT,
    FOREIGN KEY (Room_Number) REFERENCES Room(Room_Number),
    Allotment_Date DATE NOT NULL,
    Release_Date DATE NOT NULL
);

CREATE TABLE Payment (
    Payment_ID INT PRIMARY KEY,
    Student_ID INT,
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    Amount DECIMAL(10,2) DEFAULT 15000 NOT NULL,
    Due_Date DATE NOT NULL,
    Payment_Date DATE NOT NULL
);

CREATE TABLE Complaint (
    Complaint_ID INT PRIMARY KEY,
    Student_ID INT,
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
	Staff_ID INT,
    FOREIGN KEY (Staff_ID) REFERENCES Staff(Staff_ID),
    Description VARCHAR(255) NOT NULL,
    Status VARCHAR(255) NOT NULL,
    Date_of_Submission DATE NOT NULL
);

CREATE TABLE Maintenance (
    Maintenance_ID INT PRIMARY KEY,
    Room_Number INT,
    FOREIGN KEY (Room_Number) REFERENCES Room(Room_Number),
    Description VARCHAR(255) NOT NULL,
    Cost DECIMAL(10,2) NOT NULL,
    Date_of_Completion DATE NOT NULL
);

CREATE TABLE Visitor (
    Visitor_ID INT PRIMARY KEY,
    Student_ID INT,
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    Name VARCHAR(255) NOT NULL,
    Phone VARCHAR(255) NOT NULL,
    Purpose VARCHAR(255) NOT NULL,
    Date_of_Visit DATE NOT NULL,
    Time_In TIME NOT NULL,
    Time_Out TIME NOT NULL
);

CREATE TABLE Attendance (
    Attendance_ID INT PRIMARY KEY,
    Student_ID INT,
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    Date DATE NOT NULL,
    Time_In TIME NOT NULL,
    Time_Out TIME NOT NULL
);

CREATE TABLE Leave (
    Leave_ID INT PRIMARY KEY,
    Student_ID INT,
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    Start_Date DATE NOT NULL,
    End_Date DATE NOT NULL,
    Reason VARCHAR(255) NOT NULL,
    Status VARCHAR(255) NOT NULL
);

CREATE TABLE Furniture (
    Furniture_ID INT PRIMARY KEY,
    Student_ID INT,
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    Furniture_Name VARCHAR(255) NOT NULL,
    Quality VARCHAR(255) NOT NULL,
    Date_of_Issue DATE NOT NULL,
    Date_of_Back DATE NOT NULL
);

CREATE TABLE Medical (
    Medical_ID INT PRIMARY KEY,
    Student_ID INT,
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    Illness VARCHAR(255) NOT NULL,
    Date DATE NOT NULL,
    Treatment VARCHAR(255) NOT NULL
);


INSERT INTO Hostel (Hostel_ID, Hostel_Name, Hostel_Location) VALUES (1, 'Hostel A', 'Karachi');
INSERT INTO Hostel (Hostel_ID, Hostel_Name, Hostel_Location) VALUES (2, 'Hostel B', 'Islamabad');
INSERT INTO Hostel (Hostel_ID, Hostel_Name, Hostel_Location) VALUES (3, 'Hostel C', 'Rawalpindi');
INSERT INTO Hostel (Hostel_ID, Hostel_Name, Hostel_Location) VALUES (4, 'Hostel D', 'Lahore');


-- Room
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (101, 'Double', 2, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (102, 'Double', 2, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (103, 'Triple', 3, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (104, 'Double', 2, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (105, 'Double', 2, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (106, 'Triple', 3, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (107, 'Double', 2, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (108, 'Double', 2, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (109, 'Triple', 3, 'Available');
INSERT INTO Room (Room_Number, Type, Capacity, Availability) VALUES (110, 'Double', 2, 'Available');

-- Student
INSERT INTO Student (Student_ID, Name, Email, Phone, Address, Room_Number, Hostel_ID, Date_of_Admission) VALUES (1, 'John Doe', 'johndoe@example.com', '555-555-5555', '123 Main St', 101, 1, '2022-01-01');
INSERT INTO Student (Student_ID, Name, Email, Phone, Address, Room_Number, Hostel_ID, Date_of_Admission) VALUES (2, 'Jane Doe', 'janedoe@example.com', '556-555-5555', '456 Park Ave', 102, 1, '2022-01-01');
INSERT INTO Student (Student_ID, Name, Email, Phone, Address, Room_Number, Hostel_ID, Date_of_Admission) VALUES (3, 'Bob Smith', 'bobsmith@example.com', '557-555-5555', '789 Elm St', 103, 2, '2022-01-01');
INSERT INTO Student (Student_ID, Name, Email, Phone, Address, Room_Number, Hostel_ID, Date_of_Admission) VALUES (4, 'Alice Johnson', 'alicejohnson@example.com', '558-555-5555', '321 Oak St', 104, 2, '2022-01-01');
INSERT INTO Student (Student_ID, Name, Email, Phone, Address, Room_Number, Hostel_ID, Date_of_Admission) VALUES (5, 'Charlie Brown', 'charliebrown@example.com', '559-555-5555', '159 Pine St', 105, 3, '2022-01-01');
INSERT INTO Student (Student_ID, Name, Email, Phone, Address, Room_Number, Hostel_ID, Date_of_Admission) VALUES (6, 'David Johnson', 'davidjohnson@example.com', '550-555-5555','123 Pine St',106,3,'2022-01-01');
-- Staff
INSERT INTO Staff (Staff_ID, Name, Email, Phone, Address,Hostel_ID,Designation, Date_of_Joining) VALUES (1, 'John Smith', 'johnsmith@example.com', '155-555-5555', '123 Main St',1, 'Manager', '2022-01-01');
INSERT INTO Staff (Staff_ID, Name, Email, Phone, Address,Hostel_ID,Designation, Date_of_Joining) VALUES (2, 'Jane Boe', 'janedoe@example.com', '555-255-5555', '456 Park Ave',2, 'Supervisor', '2022-01-01');
INSERT INTO Staff (Staff_ID, Name, Email, Phone, Address,Hostel_ID,Designation, Date_of_Joining) VALUES (3, 'Bob Johnson', 'bobjohnson@example.com', '355-555-5555', '789 Elm St',3, 'Caretaker', '2022-01-01');
INSERT INTO Staff (Staff_ID, Name, Email, Phone, Address,Hostel_ID,Designation, Date_of_Joining) VALUES (4, 'Alice Smith', 'alicesmith@example.com', '455-555-5555', '321 Oak St',4, 'Receptionist', '2022-01-01');
INSERT INTO Staff (Staff_ID, Name, Email, Phone, Address,Hostel_ID,Designation, Date_of_Joining) VALUES (5, 'harlie Brown', 'harliebrown@example.com', '655-555-5555', '159 Pine St',1, 'Security', '2022-01-01');

-- Allotment
INSERT INTO Allotment (Allotment_ID, Student_ID, Room_Number, Allotment_Date, Release_Date) VALUES (1, 1, 101, '2022-01-01', '2022-12-31');
INSERT INTO Allotment (Allotment_ID, Student_ID, Room_Number, Allotment_Date, Release_Date) VALUES (2, 2, 102, '2022-01-01', '2022-12-31');
INSERT INTO Allotment (Allotment_ID, Student_ID, Room_Number, Allotment_Date, Release_Date) VALUES (3, 3, 103, '2022-01-01', '2022-12-31');
INSERT INTO Allotment (Allotment_ID, Student_ID, Room_Number, Allotment_Date, Release_Date) VALUES (4, 4, 104, '2022-01-01', '2022-12-31');
INSERT INTO Allotment (Allotment_ID, Student_ID, Room_Number, Allotment_Date, Release_Date) VALUES (5, 5, 105, '2022-01-01', '2022-12-31');
INSERT INTO Allotment (Allotment_ID, Student_ID, Room_Number, Allotment_Date, Release_Date) VALUES (6, 6, 106, '2022-01-01', '2022-12-31');
-- Payment
INSERT INTO Payment (Payment_ID, Student_ID, Amount, Due_Date, Payment_Date) VALUES (1, 1, 15000, '2022-01-15', '2022-01-01');
INSERT INTO Payment (Payment_ID, Student_ID, Amount, Due_Date, Payment_Date) VALUES (2, 2, 15000, '2022-01-15', '2022-01-01');
INSERT INTO Payment (Payment_ID, Student_ID, Amount, Due_Date, Payment_Date) VALUES (3, 3, 15000, '2022-01-15', '2022-01-01');
INSERT INTO Payment (Payment_ID, Student_ID, Amount, Due_Date, Payment_Date) VALUES (4, 4, 15000, '2022-01-15', '2022-01-01');
INSERT INTO Payment (Payment_ID, Student_ID, Amount, Due_Date, Payment_Date) VALUES (5, 5, 15000, '2022-01-15', '2022-01-01');
INSERT INTO Payment (Payment_ID, Student_ID, Amount, Due_Date, Payment_Date) VALUES (6, 6, 15000, '2022-01-15', '2022-01-01');

-- Complaint
INSERT INTO Complaint (Complaint_ID, Student_ID, Staff_ID, Description, Status, Date_of_Submission) VALUES (1, 1, 1, 'Broken window', 'Pending', '2022-01-01');
INSERT INTO Complaint (Complaint_ID, Student_ID, Staff_ID, Description, Status, Date_of_Submission) VALUES (2, 2, 2, 'Leaking faucet', 'Pending', '2022-01-01');
INSERT INTO Complaint (Complaint_ID, Student_ID, Staff_ID, Description, Status, Date_of_Submission) VALUES (3, 3, 3, 'Clogged drain', 'Pending', '2022-01-01');
INSERT INTO Complaint (Complaint_ID, Student_ID, Staff_ID, Description, Status, Date_of_Submission) VALUES (4, 4, 4, 'Broken bed', 'Pending', '2022-01-01');
INSERT INTO Complaint (Complaint_ID, Student_ID, Staff_ID, Description, Status, Date_of_Submission) VALUES (5, 5, 5, 'No hot water', 'Pending', '2022-01-01');

-- Maintenance
-- Maintenance
INSERT INTO Maintenance (Maintenance_ID, Room_Number, Description, Cost, Date_of_Completion) VALUES (1, 101, 'Replace window', 100, '2022-01-05');
INSERT INTO Maintenance (Maintenance_ID, Room_Number, Description, Cost, Date_of_Completion) VALUES (2, 102, 'Repair faucet', 50, '2022-01-05');
INSERT INTO Maintenance (Maintenance_ID, Room_Number, Description, Cost, Date_of_Completion) VALUES (3, 103, 'Unclog drain', 75, '2022-01-05');
INSERT INTO Maintenance (Maintenance_ID, Room_Number, Description, Cost, Date_of_Completion) VALUES (4, 104, 'Replace bed', 250, '2022-01-05');
INSERT INTO Maintenance (Maintenance_ID, Room_Number, Description, Cost, Date_of_Completion) VALUES (5, 105, 'Repair hot water heater', 500, '2022-01-05');

-- Visitor
INSERT INTO Visitor (Visitor_ID, Student_ID, Name, Phone, Purpose, Date_of_Visit, Time_In, Time_Out) VALUES (1, 1, 'Mary Smith', '555-555-5515', 'Friend', '2022-01-01', '14:00:00', '16:00:00');
INSERT INTO Visitor (Visitor_ID, Student_ID, Name, Phone, Purpose, Date_of_Visit, Time_In, Time_Out) VALUES (2, 2, 'David Jones', '555-555-5255', 'Parent', '2022-01-01', '15:00:00', '17:00:00');
INSERT INTO Visitor (Visitor_ID, Student_ID, Name, Phone, Purpose, Date_of_Visit, Time_In, Time_Out) VALUES (3, 3, 'Samantha Williams', '555-955-5555', 'Sibling', '2022-01-01', '16:00:00', '18:00:00');
INSERT INTO Visitor (Visitor_ID, Student_ID, Name, Phone, Purpose, Date_of_Visit, Time_In, Time_Out) VALUES (4, 4, 'William Brown', '555-555-0555', 'Spouse', '2022-01-01', '17:00:00', '19:00:00');
INSERT INTO Visitor (Visitor_ID, Student_ID, Name, Phone, Purpose, Date_of_Visit, Time_In, Time_Out) VALUES (5, 5, 'Ashley Davis', '555-555-5550', 'Friend', '2022-01-01', '18:00:00', '20:00:00');

-- Attendance
INSERT INTO Attendance (Attendance_ID, Student_ID, Date, Time_In, Time_Out) VALUES (1, 1, '2022-01-01', '08:00:00', '16:00:00');
INSERT INTO Attendance (Attendance_ID, Student_ID, Date, Time_In, Time_Out) VALUES (2, 2, '2022-01-01', '08:00:00', '16:00:00');
INSERT INTO Attendance (Attendance_ID, Student_ID, Date, Time_In, Time_Out) VALUES (3, 3, '2022-01-01', '08:00:00', '16:00:00');
INSERT INTO Attendance (Attendance_ID, Student_ID, Date, Time_In, Time_Out) VALUES (4, 4, '2022-01-01', '08:00:00', '16:00:00');
INSERT INTO Attendance (Attendance_ID, Student_ID, Date, Time_In, Time_Out) VALUES (5, 5, '2022-01-01', '08:00:00', '16:00:00');
INSERT INTO Attendance (Attendance_ID, Student_ID, Date, Time_In, Time_Out) VALUES (6, 6, '2022-01-01', '08:00:00', '16:00:00');
-- Leave
INSERT INTO Leave (Leave_ID, Student_ID, Start_Date, End_Date, Reason, Status) VALUES (1, 1, '2022-01-01', '2022-01-05', 'Family Emergency', 'Approved');
INSERT INTO Leave (Leave_ID, Student_ID, Start_Date, End_Date, Reason, Status) VALUES (2, 2, '2022-01-02', '2022-01-07', 'Sick', 'Approved');
INSERT INTO Leave (Leave_ID, Student_ID, Start_Date, End_Date, Reason, Status) VALUES (3, 3, '2022-01-03', '2022-01-08', 'Personal', 'Approved');
INSERT INTO Leave (Leave_ID, Student_ID, Start_Date, End_Date, Reason, Status) VALUES (4, 4, '2022-01-04', '2022-01-09', 'Vacation', 'Approved');
INSERT INTO Leave (Leave_ID, Student_ID, Start_Date, End_Date, Reason, Status) VALUES (5, 5, '2022-01-05', '2022-01-10', 'Other', 'Approved');

-- Furniture
INSERT INTO Furniture (Furniture_ID, Student_ID, Furniture_Name, Quality, Date_of_Issue, Date_of_Back) VALUES (1, 1, 'Bed', 'Good', '2022-01-01', '2022-01-05');
INSERT INTO Furniture (Furniture_ID, Student_ID, Furniture_Name, Quality, Date_of_Issue, Date_of_Back) VALUES (2, 2, 'Bed', 'Good', '2022-01-02', '2022-01-07');
INSERT INTO Furniture (Furniture_ID, Student_ID, Furniture_Name, Quality, Date_of_Issue, Date_of_Back) VALUES (3, 3, 'Bed', 'Good', '2022-01-03', '2022-01-08');
INSERT INTO Furniture (Furniture_ID, Student_ID, Furniture_Name, Quality, Date_of_Issue, Date_of_Back) VALUES (4, 4, 'Bed', 'Good', '2022-01-04', '2022-01-09');
INSERT INTO Furniture (Furniture_ID, Student_ID, Furniture_Name, Quality, Date_of_Issue, Date_of_Back) VALUES (5, 5, 'Bed', 'Good', '2022-01-04', '2022-01-09');
INSERT INTO Furniture (Furniture_ID, Student_ID, Furniture_Name, Quality, Date_of_Issue, Date_of_Back) VALUES (6, 6, 'Bed', 'Good', '2022-01-04', '2022-01-09');

-- Medical
INSERT INTO Medical (Medical_ID, Student_ID, Illness, Date, Treatment) VALUES (1, 1, 'Flu', '2022-01-01', 'Antibiotics');
INSERT INTO Medical (Medical_ID, Student_ID, Illness, Date, Treatment) VALUES (2, 2, 'Stomach ache', '2022-01-02', 'Painkillers');
INSERT INTO Medical (Medical_ID, Student_ID, Illness, Date, Treatment) VALUES (3, 3, 'Headache', '2022-01-03',�'Ibuprofen');

--update values
update Student set Name ='john cena'
where name ='john doe'

update Medical set illness ='fever'
where illness ='stomach ache'

update room set Availability='not available'
where Room_Number =104 
update room set Availability='not available'
where Room_Number =106
update room set Availability='not available'
where Room_Number =108 

select * from Student
select * from Staff
select * from Hostel
select * from Room
select * from Allotment
select * from Maintenance
select * from Visitor
select * from Attendance
select * from Leave
select * from Furniture
select * from Payment
select * from Medical
select * from Complaint


VIEWS


--for student
create view students
as
select Student_ID,Name,Room_Number,hostel.Hostel_ID,hostel.hostel_Name from Student
join Hostel
on Student.Hostel_ID=Hostel.Hostel_ID

select * from students

--view for staff
create view staffview
as
select Name,Phone,Designation,hostel.Hostel_ID,description,status,date_of_submission from Staff
join Hostel
on hostel.Hostel_ID=Staff.Hostel_ID
join Complaint
on staff.Staff_ID=Complaint.Staff_ID

select * from staffview

--view for room
create view roomview
as
select name , Student.Student_ID,room.Room_Number,type,capacity from Student
join Room
on Student.Room_Number=room.Room_Number

select * from roomview

--view for furniture
create view furnitureview
as
select Furniture_Name,Date_of_Issue,Date_of_Back,student.Student_ID,name from Furniture
join student
on Furniture.Student_ID=Student.Student_ID

select * from furnitureview


--view for visitor
create view forvisit
as
select visitor.Visitor_ID,visitor.Name,purpose,Date_of_Visit,Time_In,Time_Out,student.Student_ID from Student
join Visitor
on student.Student_ID=Visitor.Student_ID

select * from forvisit

--view for allotment
create view forallotment
as
select Allotment_ID,Allotment_Date,release_date,student.Student_ID,Student.Name,room.Room_Number from Allotment
join Student
on Allotment.Student_ID=Student.Student_ID
join Room
on Allotment.Room_Number=room.Room_Number

select * from forallotment

--view for payment
create view forpayment
as
select Payment_ID,Amount,Due_Date,Payment_Date,student.Student_ID,student.Name , student.Hostel_ID from Payment
join Student
on Payment.Student_ID=student.Student_ID

select * from forpayment

--view for leave
create view forleave
as
select Leave_ID,Start_Date,End_Date,Reason,Status,student.Student_ID,student.Name,student.Hostel_ID
from Leave
join student
on leave.Student_ID=Student.Student_ID

select * from forleave

--view for medical
create view formedical
as
select Medical_ID,Illness,Date,Treatment,student.Student_ID,student.Name,student.Hostel_ID 
from Medical
join student
on medical.Student_ID=student.Student_ID

select * from formedical

--view for complaint
create view forcomplaint
as
select Complaint_ID,Description,Status,Date_of_Submission ,staff.Staff_ID,student.Student_ID,student.Name ,leave.Reason,leave.Status
from Complaint
join Staff
on Complaint.Staff_ID=staff.Staff_ID
join student
on Complaint.Student_ID=Student.Student_ID

select * from forcomplaint







--procedures

CREATE PROCEDURE proc_student(@studentid int)
as
BEGIN
select * from students
where Student_ID=@studentid
end

exec proc_student 1


--second procedure

create procedure for_staff(@staff_id int)
as
begin
select name,email,phone,hostel.Hostel_ID,designation,hostel.Hostel_Name,hostel.Hostel_Location from Staff
join hostel
on staff.Hostel_ID=Hostel.Hostel_ID
where Staff_ID=@staff_id
end


exec for_staff 3







----FUNCTIONS

create function func(@studentid int)
returns table
as
return(select Hostel_ID,Name,Email,Room_Number,payment.Amount,medical.Illness,medical.Treatment , leave.Reason,furniture.Furniture_Name,
furniture.Date_of_Issue,Furniture.Date_of_Back,Complaint.Description,Complaint.Status,Complaint.Date_of_Submission
from Student 
join payment
on Student.Student_ID=Payment.Payment_ID
join medical
on Student.Student_ID=Medical.Student_ID
join leave
on student.Student_ID=Leave.Student_ID
join Furniture
on Student.Student_ID=Furniture.Student_ID
join Complaint
on Student.Student_ID=Complaint.Student_ID
where student.Student_ID=@studentid
)
select * from func(2)






----TRIGGERS
create trigger exceptioncase
on hostel
for insert,update
as
begin
select hostel_name,Hostel_Location  from Hostel where Hostel_Name = 'HOSTEL C' and Hostel_Location ='karachi' 
end


create trigger triggersecond
on hostel
for insert
as begin
select Hostel_ID from Hostel where Hostel_ID='k101'
end



create trigger triggerthird
on medical
for insert
as begin
select Illness from Medical where Illness like 'cancer'
end

create trigger triggerfourth
on leave
for update
as begin
select Status from Leave where Status like 'not-approved'
end


create trigger triggerfifth
on furniture
for delete
as begin
select Quality from Furniture where Quality�like�'bad'
end